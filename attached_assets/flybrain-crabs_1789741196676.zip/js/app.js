(function () {
  'use strict';

  const rand = FlyBrain.mulberry32(9001);
  const N_SENS = FlyBrain.N_SENS;
  const sensorAngle = FlyBrain.sensorAngle;
  const SENS_RANGE = 5.5;
  const SENS_CONE = Math.PI / 4.2;
  const ARENA_R = 22;

  // ---------------- renderer / scene ----------------
  const wrap = document.getElementById('canvas-wrap');
  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x06090a, 0.02);

  const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 500);
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  wrap.appendChild(renderer.domElement);

  scene.add(new THREE.AmbientLight(0x395048, 1.1));
  const key = new THREE.DirectionalLight(0xfff2e0, 1.0);
  key.position.set(8, 12, 5);
  scene.add(key);
  const rimLight = new THREE.DirectionalLight(0x6ee7d8, 0.3);
  rimLight.position.set(-6, 4, -6);
  scene.add(rimLight);

  // ground
  const groundMat = new THREE.MeshStandardMaterial({ color: 0x0a1112, roughness: 1 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(ARENA_R, 72), groundMat);
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);
  const grid = new THREE.GridHelper(ARENA_R * 2, 36, 0x1c2628, 0x14201f);
  grid.position.y = 0.01;
  scene.add(grid);
  const boundary = new THREE.Mesh(
    new THREE.RingGeometry(ARENA_R - 0.06, ARENA_R, 96),
    new THREE.MeshBasicMaterial({ color: 0xFFB454, side: THREE.DoubleSide, transparent: true, opacity: 0.3 })
  );
  boundary.rotation.x = -Math.PI / 2;
  boundary.position.y = 0.02;
  scene.add(boundary);

  function randomArenaPoint(minR) {
    let x, z, d;
    do {
      x = (rand() * 2 - 1) * ARENA_R * 0.85;
      z = (rand() * 2 - 1) * ARENA_R * 0.85;
      d = Math.hypot(x, z);
    } while (d < (minR || 0));
    return { x, z };
  }

  // ---------------- obstacles ----------------
  const obstacles = [];
  const obstacleGroup = new THREE.Group();
  scene.add(obstacleGroup);

  function makeObstacle() {
    const g = new THREE.Group();
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, 0.05, 1.0, 8),
      new THREE.MeshStandardMaterial({ color: 0x3a2a1a, roughness: 0.8 })
    );
    post.position.y = 0.5;
    g.add(post);
    const head = new THREE.Mesh(
      new THREE.CircleGeometry(0.4, 20),
      new THREE.MeshStandardMaterial({ color: 0xB23A3A, roughness: 0.6, side: THREE.DoubleSide })
    );
    head.position.y = 1.05;
    head.rotation.x = 0.15;
    g.add(head);
    return g;
  }

  function addObstacle(x, z) {
    const r = 0.6;
    const mesh = makeObstacle();
    mesh.position.set(x, 0, z);
    mesh.rotation.y = rand() * Math.PI * 2;
    obstacleGroup.add(mesh);
    obstacles.push({ x, z, r, mesh });
  }
  function seedObstacles(n) { for (let i = 0; i < n; i++) { const p = randomArenaPoint(4); addObstacle(p.x, p.z); } }

  // ---------------- food ----------------
  const food = [];
  const foodGroup = new THREE.Group();
  scene.add(foodGroup);

  function makeFoodMesh() {
    return new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.16, 0),
      new THREE.MeshStandardMaterial({ color: 0x8cff6b, emissive: 0x2f6b1f, emissiveIntensity: 0.9, roughness: 0.4 })
    );
  }
  function addFood(x, z) {
    const mesh = makeFoodMesh();
    mesh.position.set(x, 0.16, z);
    foodGroup.add(mesh);
    food.push({ x, z, r: 0.35, mesh, alive: true });
  }
  function seedFood(n) { for (let i = 0; i < n; i++) { const p = randomArenaPoint(2); addFood(p.x, p.z); } }
  function respawnFood(item) {
    const p = randomArenaPoint(2);
    item.x = p.x; item.z = p.z; item.alive = true;
    item.mesh.position.set(p.x, 0.16, p.z);
    item.mesh.visible = true;
  }

  seedObstacles(8);
  seedFood(10);

  // ---------------- creature builder (six-legged, winged, crab-styled) ----------------
  function buildCreature(tintHex, eyeHex) {
    const creature = new THREE.Group();

    const bodyMat = new THREE.MeshStandardMaterial({ color: tintHex, roughness: 0.45, metalness: 0.12 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x1a2320, roughness: 0.5 });

    // wide flattened carapace
    const carapace = new THREE.Mesh(new THREE.SphereGeometry(0.34, 20, 14), bodyMat);
    carapace.scale.set(1.35, 0.55, 1.05);
    carapace.position.set(0, 0.3, 0);
    creature.add(carapace);

    // eye stalks
    const eyeMat = new THREE.MeshStandardMaterial({ color: eyeHex, emissive: eyeHex, emissiveIntensity: 0.7 });
    [1, -1].forEach((side) => {
      const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.22, 6), darkMat);
      stalk.position.set(side * 0.12, 0.5, 0.32);
      stalk.rotation.x = -0.4;
      creature.add(stalk);
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 10), eyeMat);
      eye.position.set(side * 0.12, 0.6, 0.4);
      creature.add(eye);
    });

    // claws
    [1, -1].forEach((side) => {
      const claw = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), darkMat);
      claw.scale.set(1.3, 0.8, 1);
      claw.position.set(side * 0.32, 0.24, 0.28);
      creature.add(claw);
    });

    // wings (fly-style), mounted on the carapace
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0xcfe9e0, transparent: true, opacity: 0.3, side: THREE.DoubleSide, roughness: 0.2
    });
    const wingGeo = new THREE.PlaneGeometry(0.6, 0.24);
    const wingL = new THREE.Mesh(wingGeo, wingMat); wingL.position.set(0.18, 0.46, -0.05);
    const wingR = new THREE.Mesh(wingGeo, wingMat); wingR.position.set(-0.18, 0.46, -0.05);
    creature.add(wingL, wingR);

    // six legs, tripod-gait sticks
    const legMat = new THREE.MeshStandardMaterial({ color: 0x2a3530, roughness: 0.6 });
    const hips = [
      { x: 0.3, z: 0.26 }, { x: -0.3, z: 0.26 },
      { x: 0.34, z: 0.0 }, { x: -0.34, z: 0.0 },
      { x: 0.3, z: -0.26 }, { x: -0.3, z: -0.26 },
    ];
    const legs = hips.map((h, i) => {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1, 6), legMat);
      creature.add(leg);
      return { def: h, mesh: leg, group: i % 2 === 0 ? 'A' : 'B' };
    });

    scene.add(creature);
    return { group: creature, wingL, wingR, legs };
  }

  // ---------------- agents ----------------
  function makeAgent(id, tintHex, eyeHex, seed, startX, startZ) {
    const vis = buildCreature(tintHex, eyeHex);
    vis.group.position.set(startX, 0.02, startZ);
    return {
      id,
      vis,
      brain: new FlyBrain.Brain(seed, id),
      gaitPhase: rand() * 10,
      hipWorld: new THREE.Vector3(),
      footWorld: new THREE.Vector3(),
      footBase: new THREE.Vector3(),
    };
  }

  const bio1 = makeAgent('BIO1', 0x2a231a, 0xFFB454, 111, -4, 3);
  const bio2 = makeAgent('BIO2', 0x1a2528, 0x6EE7FF, 222, 4, -3);
  const agents = [bio1, bio2];

  function otherOf(a) { return a === bio1 ? bio2 : bio1; }

  // ---------------- sensing ----------------
  function computeConeSensors(sourcePos, heading, targets) {
    const out = new Float32Array(N_SENS);
    for (const t of targets) {
      const dx = t.x - sourcePos.x, dz = t.z - sourcePos.z;
      const dist = Math.hypot(dx, dz) - (t.r || 0);
      if (dist > SENS_RANGE) continue;
      const worldAngle = Math.atan2(dx, dz);
      const relAngle = worldAngle - heading;
      for (let i = 0; i < N_SENS; i++) {
        let diff = sensorAngle(i) - relAngle;
        diff = Math.atan2(Math.sin(diff), Math.cos(diff));
        if (Math.abs(diff) < SENS_CONE) {
          const strength = Math.max(0, 1 - Math.max(dist, 0) / SENS_RANGE);
          out[i] = Math.max(out[i], strength);
        }
      }
    }
    return out;
  }

  function boundarySensor(sourcePos, heading) {
    const out = new Float32Array(N_SENS);
    const distToEdge = ARENA_R - Math.hypot(sourcePos.x, sourcePos.z);
    if (distToEdge < SENS_RANGE) {
      const worldAngle = Math.atan2(sourcePos.x, sourcePos.z);
      const relAngle = worldAngle - heading;
      for (let i = 0; i < N_SENS; i++) {
        let diff = sensorAngle(i) - relAngle;
        diff = Math.atan2(Math.sin(diff), Math.cos(diff));
        if (Math.abs(diff) < SENS_CONE) {
          out[i] = Math.max(out[i], Math.max(0, 1 - Math.max(distToEdge, 0) / SENS_RANGE) * 0.9);
        }
      }
    }
    return out;
  }

  // ---------------- movement + gait ----------------
  const BASE_SPEED = 1.7;
  const GAIT_FREQ = 7.0;

  function setLegSpan(leg, hip, foot) {
    const mid = new THREE.Vector3().addVectors(hip, foot).multiplyScalar(0.5);
    const dir = new THREE.Vector3().subVectors(foot, hip);
    const len = Math.max(dir.length(), 0.05);
    leg.mesh.position.copy(mid);
    leg.mesh.scale.set(1, len, 1);
    const up = new THREE.Vector3(0, 1, 0);
    const quat = new THREE.Quaternion().setFromUnitVectors(up, dir.clone().normalize());
    leg.mesh.setRotationFromQuaternion(quat);
  }

  function stepAgentMovement(agent, dt) {
    const g = agent.vis.group;
    const b = agent.brain;
    g.rotation.y += b.turnRate * dt;
    const speed = BASE_SPEED * b.speedFactor;
    g.position.x += Math.sin(g.rotation.y) * speed * dt;
    g.position.z += Math.cos(g.rotation.y) * speed * dt;

    const d = Math.hypot(g.position.x, g.position.z);
    if (d > ARENA_R - 0.4) {
      const k = (ARENA_R - 0.4) / d;
      g.position.x *= k; g.position.z *= k;
    }

    agent.gaitPhase += dt * GAIT_FREQ * (0.3 + b.speedFactor * 0.9);
    g.position.y = 0.02 + Math.abs(Math.sin(agent.gaitPhase * 2)) * 0.012;

    for (const leg of agent.vis.legs) {
      const phase = agent.gaitPhase + (leg.group === 'A' ? 0 : Math.PI);
      const lift = Math.max(0, Math.sin(phase)) * 0.16;
      const stride = Math.cos(phase) * 0.18;
      agent.hipWorld.set(leg.def.x, 0.26, leg.def.z);
      agent.hipWorld.applyMatrix4(g.matrixWorld);
      agent.footBase.set(leg.def.x * 1.6, 0, leg.def.z + stride * 0.6);
      agent.footWorld.copy(agent.footBase);
      agent.footWorld.applyMatrix4(g.matrixWorld);
      agent.footWorld.y = lift;
      setLegSpan(leg, agent.hipWorld, agent.footWorld);
    }

    const flap = Math.sin(performance.now() * 0.05 + (agent.id === 'BIO1' ? 0 : 1.7)) * 0.6 + 0.6;
    agent.vis.wingL.rotation.z = flap * 0.9;
    agent.vis.wingR.rotation.z = -flap * 0.9;
  }

  // ---------------- food consumption ----------------
  function checkFoodConsumption(agent) {
    const pos = agent.vis.group.position;
    for (const item of food) {
      if (!item.alive) continue;
      const d = Math.hypot(item.x - pos.x, item.z - pos.z);
      if (d < item.r + 0.3) {
        item.alive = false;
        item.mesh.visible = false;
        agent.brain.eat();
        setTimeout(() => respawnFood(item), 3000 + rand() * 4000);
      }
    }
  }

  // ---------------- camera: auto-follow + manual orbit override ----------------
  let followId = 'BIO1';
  let camAngle = 0.6, camElev = 0.5, camDist = 5.5;
  let dragging = false, lastX = 0, lastY = 0;
  let pinchStartDist = null, pinchStartCamDist = camDist;

  function followedAgent() { return followId === 'BIO1' ? bio1 : bio2; }

  function screenToDelta(dxPx, dyPx) {
    camAngle -= dxPx * 0.006;
    camElev = Math.max(0.15, Math.min(1.4, camElev + dyPx * 0.006));
  }

  renderer.domElement.addEventListener('pointerdown', (e) => {
    dragging = true; lastX = e.clientX; lastY = e.clientY;
  });
  window.addEventListener('pointerup', () => { dragging = false; });
  window.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    screenToDelta(e.clientX - lastX, e.clientY - lastY);
    lastX = e.clientX; lastY = e.clientY;
  });
  renderer.domElement.addEventListener('wheel', (e) => {
    camDist = Math.max(2.2, Math.min(18, camDist + e.deltaY * 0.004));
  }, { passive: true });

  // touch: single-finger drag to orbit, two-finger pinch to zoom
  renderer.domElement.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
      dragging = true; lastX = e.touches[0].clientX; lastY = e.touches[0].clientY;
    } else if (e.touches.length === 2) {
      dragging = false;
      pinchStartDist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      pinchStartCamDist = camDist;
    }
  }, { passive: true });
  renderer.domElement.addEventListener('touchmove', (e) => {
    if (e.touches.length === 1 && dragging) {
      screenToDelta(e.touches[0].clientX - lastX, e.touches[0].clientY - lastY);
      lastX = e.touches[0].clientX; lastY = e.touches[0].clientY;
    } else if (e.touches.length === 2 && pinchStartDist) {
      const d = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const scale = pinchStartDist / Math.max(d, 1);
      camDist = Math.max(2.2, Math.min(18, pinchStartCamDist * scale));
    }
  }, { passive: true });
  renderer.domElement.addEventListener('touchend', (e) => {
    if (e.touches.length === 0) { dragging = false; pinchStartDist = null; }
  }, { passive: true });

  function updateCamera() {
    const target = followedAgent().vis.group.position.clone().add(new THREE.Vector3(0, 0.3, 0));
    const x = target.x + Math.sin(camAngle) * camDist * Math.cos(camElev);
    const z = target.z + Math.cos(camAngle) * camDist * Math.cos(camElev);
    const y = target.y + camDist * Math.sin(camElev);
    camera.position.set(x, y, z);
    camera.lookAt(target);
  }

  // ---------------- terminal log ----------------
  const termBody = document.getElementById('term-body');
  const JARGON = {
    'wander': ['baseline spontaneous firing, no dominant drive', 'central complex heading integrator idle-drifting'],
    'forage': ['chemotactic relay engaged — odor gradient ascending', 'foraging descending pathway active'],
    'avoid-obstacle': ['lateral inhibition sharpening — obstacle contour resolved', 'avoidance steering vector engaged'],
    'escape': ['giant-fiber-style escape triggered — jump reflex fired', 'high-gain startle burst on descending pathway'],
    'investigate': ['conspecific detected — approach vector engaged', 'social relay bias positive, orienting toward BIO'],
    'avoid-agent': ['conspecific detected — withdrawal vector engaged', 'social relay bias negative, disengaging'],
    'contest-resource': ['overlapping resource claim detected', 'competitive approach — resource contest state']
  };
  function pushLog(agentId, mode, extra) {
    const div = document.createElement('div');
    div.className = 'line ' + (agentId === 'BIO1' ? 'b1' : 'b2');
    const phrases = JARGON[mode] || JARGON['wander'];
    const phrase = phrases[Math.floor(rand() * phrases.length)];
    const ts = new Date().toISOString().substr(11, 8);
    div.textContent = `[${ts}] ${agentId} :: ${phrase} ${extra || ''}`;
    termBody.appendChild(div);
    while (termBody.children.length > 60) termBody.removeChild(termBody.firstChild);
    termBody.scrollTop = termBody.scrollHeight;
  }
  let logTimer = 0;
  function sysLog(msg) {
    const div = document.createElement('div');
    div.className = 'line sys';
    const ts = new Date().toISOString().substr(11, 8);
    div.textContent = `[${ts}] SYS :: ${msg}`;
    termBody.appendChild(div);
    termBody.scrollTop = termBody.scrollHeight;
  }

  // ---------------- scan overlay ----------------
  const scanCanvas = document.getElementById('scan-canvas');
  const scanRenderer = initScanRenderer(scanCanvas);
  window.addEventListener('resize', () => scanRenderer.resize());

  // ---------------- UI wiring ----------------
  document.getElementById('btn-enter').addEventListener('click', () => {
    document.body.classList.add('entered');
    scanRenderer.resize();
    sysLog('runtime initialized — two independent circuit instances online');
  });

  document.getElementById('btn-follow-1').addEventListener('click', (e) => setFollow('1', e.target));
  document.getElementById('btn-follow-2').addEventListener('click', (e) => setFollow('2', e.target));
  function setFollow(num, btn) {
    followId = 'BIO' + num;
    document.querySelectorAll('.follow-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }

  function wirePanelToggle(btnId, panelId) {
    const btn = document.getElementById(btnId);
    const panel = document.getElementById(panelId);
    btn.addEventListener('click', () => {
      const nowHidden = panel.classList.toggle('hidden');
      btn.classList.toggle('active', !nowHidden);
    });
  }
  wirePanelToggle('btn-toggle-scan', 'scan-panel');
  wirePanelToggle('btn-toggle-term', 'term-panel');
  wirePanelToggle('btn-toggle-info', 'info-panel');
  document.querySelectorAll('.close-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-close');
      document.getElementById(id).classList.add('hidden');
      const map = { 'scan-panel': 'btn-toggle-scan', 'term-panel': 'btn-toggle-term', 'info-panel': 'btn-toggle-info' };
      const toggleBtn = document.getElementById(map[id]);
      if (toggleBtn) toggleBtn.classList.remove('active');
    });
  });

  document.getElementById('btn-obstacle').addEventListener('click', () => {
    const p = randomArenaPoint(2); addObstacle(p.x, p.z);
  });
  document.getElementById('btn-food').addEventListener('click', () => {
    const p = randomArenaPoint(2); addFood(p.x, p.z);
  });
  document.getElementById('btn-reset').addEventListener('click', () => {
    obstacles.length = 0; obstacleGroup.clear(); seedObstacles(8);
    food.length = 0; foodGroup.clear(); seedFood(10);
    bio1.vis.group.position.set(-4, 0.02, 3); bio1.vis.group.rotation.y = 0;
    bio2.vis.group.position.set(4, 0.02, -3); bio2.vis.group.rotation.y = Math.PI;
    agents.forEach(a => { a.brain = new FlyBrain.Brain(a.id === 'BIO1' ? 111 : 222, a.id); });
    sysLog('environment reset — both circuit instances reinitialized');
  });

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // ---------------- main loop ----------------
  const clock = new THREE.Clock();

  function animate() {
    requestAnimationFrame(animate);
    const dt = Math.min(clock.getDelta(), 0.05);

    for (const agent of agents) {
      agent.brain.otherFoodDrive = otherOf(agent).brain.foodDrive;
    }
    for (const agent of agents) {
      const pos = agent.vis.group.position;
      const heading = agent.vis.group.rotation.y;
      const other = otherOf(agent);

      const obs = computeConeSensors(pos, heading, obstacles);
      const bnd = boundarySensor(pos, heading);
      for (let i = 0; i < N_SENS; i++) agent.brain.obstacleSensors[i] = Math.max(obs[i], bnd[i]);

      const alive = food.filter(f => f.alive);
      const fs = computeConeSensors(pos, heading, alive);
      agent.brain.foodSensors.set(fs);

      const os = computeConeSensors(pos, heading, [{ x: other.vis.group.position.x, z: other.vis.group.position.z, r: 0.4 }]);
      agent.brain.otherSensors.set(os);

      const telemetry = agent.brain.step(dt);
      stepAgentMovement(agent, dt);
      checkFoodConsumption(agent);

      logTimer -= dt;
      if (telemetry.escape || (logTimer <= 0 && rand() < 0.5)) {
        pushLog(agent.id, telemetry.mode,
          `[hunger ${telemetry.hunger.toFixed(2)} valence ${telemetry.socialValence.toFixed(2)} turn ${telemetry.turnRate.toFixed(2)}]`);
      }
    }
    if (logTimer <= 0) logTimer = 1.4 + rand() * 1.6;

    updateCamera();
    scanRenderer.update(dt);
    renderer.render(scene, camera);
  }
  animate();

})();
