// brain.js — circuit-motif neural controller for one agent.
// Not the literal downloaded connectome weights: a hand-authored network built from the
// same class of motifs documented in the published male Drosophila CNS connectome
// (sensory relay, center-surround lateral inhibition, chemotaxis-style foraging,
// giant-fiber-style escape). Swappable later for a real extracted subgraph — see README.

(function (global) {
  'use strict';

  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  const N_SENS = 8;
  const LEFT_GROUP = [5, 6, 7];
  const RIGHT_GROUP = [1, 2, 3];
  const FRONT_IDX = 0;

  function sensorAngle(i) { return i * (Math.PI * 2 / N_SENS); }

  class Brain {
    constructor(seed, label) {
      this.label = label || 'BIO';
      this.rand = mulberry32(seed >>> 0);

      // sensory input arrays (filled externally each frame, in agent-local space)
      this.obstacleSensors = new Float32Array(N_SENS);
      this.foodSensors = new Float32Array(N_SENS);
      this.otherSensors = new Float32Array(N_SENS);

      // internal layers
      this.obstacleRelay = new Float32Array(N_SENS);
      this.obstacleLateral = new Float32Array(N_SENS);
      this.foodRelay = new Float32Array(N_SENS);
      this.otherRelay = new Float32Array(N_SENS);

      // drives / state
      this.hunger = 0.35 + this.rand() * 0.2;
      this.socialValence = (this.rand() * 2 - 1) * 0.4;
      this.socialTarget = this.socialValence;
      this.socialRetimer = 4 + this.rand() * 8;

      this.turnRate = 0;
      this.speedFactor = 1;
      this.frontDanger = 0;
      this.frontOther = 0;
      this.foodDrive = 0;
      this.otherDistNorm = 1; // 0 = touching, 1 = far/none

      this.escapeEvents = 0;
      this.justEscaped = false;
      this.mode = 'wander';
      this.lastMode = 'wander';
      this.modeTimer = 0;

      // set externally by the sim each frame: the other agent's current foodDrive,
      // used to resolve who "wins" a contested resource
      this.otherFoodDrive = 0;
      // fixed per-individual circling handedness, so investigate reads as orbiting
      // rather than colliding — a stand-in for the idiosyncratic asymmetry documented
      // in real flies with identical genomes
      this.orbitBias = this.rand() > 0.5 ? 1 : -1;
      this._escapeWindup = 0;

      this._noisePhase = this.rand() * 100;
      this._t = 0;
    }

    eat() {
      this.hunger = Math.max(0, this.hunger - 0.55);
    }

    step(dt) {
      this._t += dt;

      // --- obstacle channel: leaky relay + center-surround lateral inhibition ---
      for (let i = 0; i < N_SENS; i++) {
        this.obstacleRelay[i] = Math.tanh(this.obstacleSensors[i] * 1.6 + this.obstacleRelay[i] * 0.35);
      }
      for (let i = 0; i < N_SENS; i++) {
        const l = this.obstacleRelay[(i - 1 + N_SENS) % N_SENS];
        const r = this.obstacleRelay[(i + 1) % N_SENS];
        this.obstacleLateral[i] = Math.tanh(this.obstacleRelay[i] * 1.3 - (l + r) * 0.4);
      }
      const leftDanger = LEFT_GROUP.reduce((s, i) => s + this.obstacleLateral[i], 0) / LEFT_GROUP.length;
      const rightDanger = RIGHT_GROUP.reduce((s, i) => s + this.obstacleLateral[i], 0) / RIGHT_GROUP.length;
      this.frontDanger = Math.max(0, this.obstacleLateral[FRONT_IDX]);

      // --- food channel: simple leaky relay (chemotaxis-style, no lateral inhibition) ---
      for (let i = 0; i < N_SENS; i++) {
        this.foodRelay[i] = Math.tanh(this.foodSensors[i] * 1.4 + this.foodRelay[i] * 0.4);
      }
      const leftFood = LEFT_GROUP.reduce((s, i) => s + this.foodRelay[i], 0) / LEFT_GROUP.length;
      const rightFood = RIGHT_GROUP.reduce((s, i) => s + this.foodRelay[i], 0) / RIGHT_GROUP.length;
      this.foodDrive = Math.max(this.foodRelay[FRONT_IDX], (leftFood + rightFood) / 2);

      // hunger rises slowly over time, sharpens food-seeking gain
      this.hunger = Math.min(1, this.hunger + dt * 0.012);
      const hungerGain = 0.4 + this.hunger * 1.1;

      // --- social channel: leaky relay on other-agent presence ---
      for (let i = 0; i < N_SENS; i++) {
        this.otherRelay[i] = Math.tanh(this.otherSensors[i] * 1.5 + this.otherRelay[i] * 0.3);
      }
      const leftOther = LEFT_GROUP.reduce((s, i) => s + this.otherRelay[i], 0) / LEFT_GROUP.length;
      const rightOther = RIGHT_GROUP.reduce((s, i) => s + this.otherRelay[i], 0) / RIGHT_GROUP.length;
      this.frontOther = Math.max(0, this.otherRelay[FRONT_IDX]);
      this.otherDistNorm = 1 - Math.max(this.frontOther, (leftOther + rightOther) / 2);

      // social valence: slow stochastic drift — decides whether "notice" reads as
      // investigate/compete (positive) or avoid (negative). Deliberately unscripted.
      this.socialRetimer -= dt;
      if (this.socialRetimer <= 0) {
        this.socialTarget = (this.rand() * 2 - 1);
        this.socialRetimer = 4 + this.rand() * 10;
      }
      this.socialValence += (this.socialTarget - this.socialValence) * Math.min(1, dt * 0.6);

      // --- combine into steering ---
      this._noisePhase += dt;
      const wander = Math.sin(this._noisePhase * 0.37) + Math.sin(this._noisePhase * 0.71) * 0.5;

      const obstacleTurn = (leftDanger - rightDanger) * 2.4;
      const foodTurn = (rightFood - leftFood) * 1.3 * hungerGain;
      const socialTurn = (rightOther - leftOther) * 1.6 * this.socialValence;

      let targetTurn = obstacleTurn + foodTurn * 0.65 + socialTurn + wander * 0.22;
      let targetSpeed = Math.max(0.12, 1 - this.frontDanger * 1.35);

      // --- classify a human-readable mode, with hysteresis so it doesn't flicker
      // between near-tied candidates every frame ---
      const inContest = this.otherDistNorm < 0.55 && this.socialValence > 0.35 && this.foodDrive > 0.2;
      let candidate;
      if (this.frontDanger > 0.3) candidate = 'avoid-obstacle';
      else if (inContest) candidate = 'contest-resource';
      else if (this.otherDistNorm < 0.55 && this.socialValence > 0.12) candidate = 'investigate';
      else if (this.otherDistNorm < 0.55 && this.socialValence < -0.12) candidate = 'avoid-agent';
      else if (this.foodDrive > 0.22) candidate = 'forage';
      else candidate = 'wander';

      this.modeTimer += dt;
      const MIN_DWELL = 0.35;
      if (candidate !== this.lastMode && this.modeTimer >= MIN_DWELL) {
        this.lastMode = candidate;
        this.modeTimer = 0;
      }
      this.mode = this.lastMode;

      // contest resolution: compare food drives (a proxy for who's closer/more
      // committed) — the trailing agent backs off rather than pushing forever
      if (this.mode === 'contest-resource') {
        if (this.foodDrive + 0.05 < this.otherFoodDrive) {
          // losing: withdraw
          this.socialTarget = Math.min(this.socialTarget, -0.3);
          targetSpeed *= 0.55;
        } else {
          // winning or roughly even: press the claim
          targetSpeed = Math.min(1.4, targetSpeed + 0.35);
        }
      }

      // investigate: approach until close, then orbit rather than collide
      if (this.mode === 'investigate' && this.otherDistNorm < 0.28) {
        targetTurn += this.orbitBias * 1.8;
        targetSpeed = Math.min(targetSpeed, 0.7);
      }

      // approach speed boost when curious and other agent is at a comfortable distance
      if (this.socialValence > 0.15 && this.otherDistNorm < 0.6 && this.mode !== 'contest-resource') {
        targetSpeed = Math.min(1.3, targetSpeed + 0.25 * this.socialValence);
      }
      // foraging speed boost when hungry and food is ahead
      if (this.foodDrive > 0.25) {
        targetSpeed = Math.min(1.35, targetSpeed + this.foodDrive * 0.4);
      }

      this.justEscaped = false;
      const dangerTriggered = this.frontDanger > 0.62;
      const loomTriggered = this.frontOther > 0.72 && this.socialValence < -0.35;

      if ((dangerTriggered || loomTriggered) && this._escapeWindup <= 0 && this.mode !== 'escape') {
        // giant-fiber-style latency: a brief freeze before the explosive turn,
        // mirroring the short delay real escape circuits show before the jump
        this._escapeWindup = 0.09;
        this.mode = 'escape';
        this.lastMode = 'escape';
        this.modeTimer = 0;
      }

      if (this._escapeWindup > 0) {
        this._escapeWindup -= dt;
        targetTurn = this.turnRate; // hold heading during the freeze
        targetSpeed = 0.05;
        if (this._escapeWindup <= 0) {
          this.escapeEvents++;
          this.justEscaped = true;
          const burst = dangerTriggered ? 3.2 : 2.6;
          targetTurn = this.turnRate + (this.rand() > 0.5 ? 1 : -1) * burst;
          targetSpeed = 1.4;
        }
      }

      this.turnRate += (targetTurn - this.turnRate) * Math.min(1, dt * 4);
      this.speedFactor += (targetSpeed - this.speedFactor) * Math.min(1, dt * 3);

      return {
        turnRate: this.turnRate,
        speedFactor: this.speedFactor,
        frontDanger: this.frontDanger,
        hunger: this.hunger,
        socialValence: this.socialValence,
        mode: this.mode,
        escape: this.justEscaped
      };
    }
  }

  global.FlyBrain = { Brain, mulberry32, N_SENS, sensorAngle, LEFT_GROUP, RIGHT_GROUP, FRONT_IDX };

})(window);
