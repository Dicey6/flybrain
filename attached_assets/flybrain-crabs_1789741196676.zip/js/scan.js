// scan.js — a stylized, procedurally generated "connectome scan" render.
// This is NOT real EM data (no network access to pull an actual Janelia scan mesh) —
// it's a dense branching node-and-fiber structure styled to read like one, for the
// corner overlay. Swap in a real mesh/point-cloud later if one is supplied.

function initScanRenderer(canvas) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x030504);
  scene.fog = new THREE.FogExp2(0x030504, 0.09);

  const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 50);
  camera.position.set(0, 0, 6.2);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  scene.add(new THREE.AmbientLight(0x1a2a24, 1.2));
  const key = new THREE.PointLight(0x8cff6b, 1.4, 20);
  key.position.set(3, 2, 4);
  scene.add(key);
  const rim = new THREE.PointLight(0xff5fc4, 1.0, 20);
  rim.position.set(-3, -2, -3);
  scene.add(rim);

  // soft glow sprite texture, generated on a small canvas
  function glowTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.35, 'rgba(255,255,255,0.5)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  }
  const glowTex = glowTexture();

  const group = new THREE.Group();
  scene.add(group);

  // deterministic-ish branching structure: recursive node placement, dendritic feel
  const rand = FlyBrain.mulberry32(20260918);
  const nodes = [];
  function branch(origin, dir, depth, maxDepth) {
    nodes.push(origin.clone());
    if (depth >= maxDepth) return;
    const children = depth < 2 ? 3 : (rand() > 0.4 ? 2 : 1);
    for (let c = 0; c < children; c++) {
      const spread = 0.55 + rand() * 0.5;
      const newDir = dir.clone().applyAxisAngle(
        new THREE.Vector3(rand() - 0.5, rand() - 0.5, rand() - 0.5).normalize(),
        spread
      ).normalize();
      const len = (1.6 - depth * 0.28) * (0.6 + rand() * 0.5);
      const next = origin.clone().add(newDir.clone().multiplyScalar(Math.max(len, 0.18)));
      branch(next, newDir, depth + 1, maxDepth);
      // fiber line
      const geo = new THREE.BufferGeometry().setFromPoints([origin, next]);
      const mat = new THREE.LineBasicMaterial({
        color: depth % 2 === 0 ? 0x8cff6b : 0xff5fc4,
        transparent: true, opacity: 0.35
      });
      group.add(new THREE.Line(geo, mat));
    }
  }
  for (let s = 0; s < 5; s++) {
    const dir = new THREE.Vector3(rand() - 0.5, rand() - 0.5, rand() - 0.5).normalize();
    branch(new THREE.Vector3(0, 0, 0), dir, 0, 5);
  }

  // glowing node sprites
  const spriteGroupA = new THREE.Group(); // excitatory-toned
  const spriteGroupB = new THREE.Group(); // inhibitory-toned
  nodes.forEach((p, i) => {
    const excitatory = i % 3 !== 0;
    const mat = new THREE.SpriteMaterial({
      map: glowTex,
      color: excitatory ? 0x8cff6b : 0xff5fc4,
      transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false
    });
    const spr = new THREE.Sprite(mat);
    const s = 0.05 + rand() * 0.09;
    spr.scale.set(s, s, s);
    spr.position.copy(p);
    (excitatory ? spriteGroupA : spriteGroupB).add(spr);
  });
  group.add(spriteGroupA, spriteGroupB);

  // recenter group
  const box = new THREE.Box3().setFromObject(group);
  const center = box.getCenter(new THREE.Vector3());
  group.position.sub(center);

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (w === 0 || h === 0) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  let t = 0;
  function update(dt) {
    t += dt;
    group.rotation.y += dt * 0.18;
    group.rotation.x = Math.sin(t * 0.11) * 0.15;
    key.intensity = 1.2 + Math.sin(t * 1.7) * 0.3;
    renderer.render(scene, camera);
  }

  resize();
  return { update, resize };
}
