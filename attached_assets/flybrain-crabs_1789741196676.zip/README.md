# BIO1 / BIO2 — Dual Flybrain-Crab Embodiment Runtime

A two-agent, 3D, connectome-motif-driven embodiment study. Two independent circuit
instances (BIO1, BIO2) — sensory relay, center-surround lateral inhibition,
chemotaxis-style foraging, giant-fiber-style escape, and a stochastic social-valence
channel — each drive a six-legged, winged, crab-styled body in a shared arena. They
perceive each other; whether that reads as avoidance, investigation, or resource
contest is emergent, not scripted.

This is **not** the literal downloaded connectome weight matrix — see "Swapping in
real data" below for how to get there.

## Run locally

No build step. Any static file server works:

```bash
npx serve .
# or
python3 -m http.server 8000
```

Then open the printed local URL.

## Deploy to Vercel

```bash
npm i -g vercel   # if you don't have it
vercel             # from this folder, follow the prompts
vercel --prod      # promote to production
```

Or connect this folder/repo in the Vercel dashboard — it's a static site
(`vercel.json` already declares no build step), so no framework config is needed.

## Project structure

```
index.html        landing overlay + app shell + panel markup
css/style.css      all styling (dark research-instrument aesthetic)
js/brain.js        the neural circuit (Brain class) — sensing, drives, steering
js/scan.js         procedural rotating "connectome scan" corner render
js/app.js          world, creatures, camera, terminal log, UI wiring
assets/            drop your generated crab-carapace texture here (see below)
data/              drop a real extracted connectome subgraph here later (see below)
```

## Adding your DALL-E-generated crab texture

1. Generate the texture (a prompt was drafted earlier in this project's chat —
   top-down, flat-lit carapace shot, no background).
2. Save it as `assets/carapace.png` (or .jpg).
3. In `js/app.js`, inside `buildCreature()`, replace the `bodyMat` definition:

```js
const carapaceTex = new THREE.TextureLoader().load('assets/carapace.png');
const bodyMat = new THREE.MeshStandardMaterial({ map: carapaceTex, roughness: 0.45 });
```

## Swapping in the real connectome data

Right now `js/brain.js` is a hand-authored circuit built from the same *class* of
motifs documented in the published male *Drosophila* CNS connectome (Google Research
× HHMI Janelia × Cambridge × MRC-LMB, *Cell*, Sept 2026 — 166,700 neurons, 125M
synapses, dataset `male-cns:v1.0` on neuPrint). It is not those literal weights.

To get real data in:

1. Create a free account + API token at neuprint.janelia.org.
2. `pip install neuprint-python`
3. Pull a named, well-documented pathway rather than the whole brain at synapse
   resolution (166,700 neurons / 125M synapses is roughly 1.5–2GB raw — not
   browser-shippable). Good candidates:
   - **Giant Fiber escape circuit** — maps directly onto the escape reflex
   - **Olfactory pathway** (ORN → antennal lobe → lateral horn/mushroom body →
     descending neurons) — maps onto the foraging/chemotaxis channel
4. Collapse to a **neuron-pair weighted graph** (source, target, synapse-count
   weight) rather than per-synapse edges — this is the standard move (Janelia does
   the same for the smaller Hemibrain dataset) and shrinks the export by orders of
   magnitude while still being the real wiring.
5. Export as JSON/binary to `data/connectome.json` and rewire `js/brain.js` to load
   real weight matrices in place of the hand-authored ones. The sensor/motor
   interface (8-direction cones in, turnRate/speedFactor out) can stay the same
   shape — only the internal weights change.

## Notes

- No player-controlled agent, no score, no win state — this is an observation
  instrument, not a game.
- Camera: auto-follows the selected BIO; drag (or single-finger touch drag) to orbit
  around it, scroll or pinch to zoom. Tap BIO1/BIO2 in the top bar to switch focus.
- The corner "scan" render is procedurally generated for now (see `js/scan.js`) —
  swap in a real scan mesh/point cloud if you get one exported from Neuroglancer.
